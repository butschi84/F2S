const http = require('http');
const url = require('url');

// get a random delay from 200ms to 5000ms
function getRandomDelay() {
  return Math.floor(Math.random() * (5000 - 200 + 1)) + 200;
}

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true); // Parse the URL including query parameters
  const { pathname, query } = parsedUrl;

  const delay = query.delay ? parseInt(query.delay) : getRandomDelay();

  try {
    
      // Simulating delay before responding
      setTimeout(() => {
        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        res.end('REQUEST DONE');
      }, delay);
  }catch(ex){
    console.log(`there was an error: ${ex}`)
  }
});

// f2sfizzlet will act in "reverseproxy mode", when there is a service listening on 8080
const port = 8080;

server.listen(port, () => {
  console.log(`Server running at http://0.0.0.0:${port}/`);
});
