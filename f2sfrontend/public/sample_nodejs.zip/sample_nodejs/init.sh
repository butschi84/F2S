#!/bin/bash

# start your nodejs app
npm start &

# start f2sfizzlet (will act as reverseproxy to http://127.0.0.1:8080)
./f2sfizzlet &

# wait for any process to exit
wait -n

# exit with status of process that exited first
exit $?